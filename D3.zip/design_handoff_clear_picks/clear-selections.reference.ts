/**
 * Data-layer reference for "Clear picks". Two additions to existing files — shown here
 * together for review; land them in their real homes:
 *
 *   §1 → src/features/weekly-plan/api.ts       (new `clearSelections`)
 *   §2 → src/features/weekly-plan/hooks.ts     (new `useClearSelections`, `useRestoreSelections`)
 *
 * Why a dedicated call instead of N × useToggleSelection: `useToggleSelection` decides its
 * add/remove action from a `currentPlan` snapshot passed by the caller (see
 * `toggle-selection.ts`), so firing it three times in a row from one snapshot is exactly the
 * stale-snapshot hazard CatalogPage's `selectionDisabled` comment already guards against.
 * One delete keyed on the plan id is atomic and gives Undo a single failure point.
 */

/* ─────────────────────────────────────────────────────────────────────────
   §1  api.ts
   ───────────────────────────────────────────────────────────────────────── */

// import { supabase } from '@/shared/lib/supabase';

/**
 * Removes every selection on a plan in one statement. Idempotent — clearing an
 * already-empty plan is a no-op success. Does NOT delete the plan itself: an empty
 * draft plan is a valid state the catalog already renders ("0 of 3").
 *
 * RLS: `weekly_plan_selections` is household-scoped (migration
 * 20260828232000_account_model_household_scoped_rls.sql), so a plan id from another
 * household deletes zero rows rather than erroring. Callers only ever pass the id from
 * `useCurrentPlan()`, so that path is unreachable in the UI.
 */
export async function clearSelections(planId: string): Promise<void> {
  const { error } = await supabase.from('weekly_plan_selections').delete().eq('weekly_plan_id', planId);
  if (error) throw error;
}

/* ─────────────────────────────────────────────────────────────────────────
   §2  hooks.ts
   ───────────────────────────────────────────────────────────────────────── */

// const currentPlanKey = ['weekly-plan', 'current'] as const;   // already defined in hooks.ts

/**
 * Clears the live plan's picks. Returns the dinner ids it removed so the caller can
 * offer Undo without re-reading the (now empty) plan.
 */
export function useClearSelections() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ plan }: { plan: CurrentPlan }) => {
      const dinnerIds = plan.weekly_plan_selections.map((s) => s.dinner_id);
      await clearSelections(plan.id);
      return dinnerIds;
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: currentPlanKey });
    },
  });
}

/**
 * Undo for the above: re-adds the ids in their original order, sequentially, so the
 * 1/2/3 badges on the plan page come back the way they were. Sequential (not
 * Promise.all) because ordering is derived from insert order.
 */
export function useRestoreSelections() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ planId, dinnerIds }: { planId: string; dinnerIds: string[] }) => {
      for (const dinnerId of dinnerIds) {
        await addSelection(planId, dinnerId);
      }
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: currentPlanKey });
    },
  });
}
