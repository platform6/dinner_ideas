/**
 * ClearPicksControl — reference implementation for the catalog header "Clear picks" control.
 *
 * Design reference: ../Reset Dinner Selection.dc.html (option 1a).
 * This file is a REFERENCE, not a drop-in: it is written against the repo's current
 * Chakra theme (`src/shared/theme/index.ts`) and icon map (`src/shared/components/icons.tsx`),
 * but it has no tests and has not been run. Adapt names/paths to match the codebase.
 *
 * Suggested location: src/features/weekly-plan/components/ClearPicksControl.tsx
 *
 * Renders one of three inline states in place of itself:
 *   idle     → [ Clear picks ]  (quiet button; renders nothing when count === 0)
 *   confirm  → [ Clear all 3?  Keep | Clear all ]  (terracotta inline confirm)
 *   cleared  → handled by the PARENT, not here (see the undo bar in CatalogPage notes)
 */

import { useState } from 'react';
import { Button, HStack, Text } from '@chakra-ui/react';

import { uiIcons } from '@/shared/components/icons';

interface ClearPicksControlProps {
  /** Number of dinners currently picked for the live plan. 0 hides the control entirely. */
  count: number;
  /** Fired once the user confirms. Parent owns the mutation and the undo bar. */
  onClear: () => void;
  /** True while the clear mutation is in flight. */
  isClearing?: boolean;
}

export function ClearPicksControl({ count, onClear, isClearing = false }: ClearPicksControlProps) {
  const [isConfirming, setIsConfirming] = useState(false);

  if (count === 0) return null;

  if (!isConfirming) {
    return (
      <Button
        variant="quiet"
        size="sm"
        leftIcon={<uiIcons.restore size={13} strokeWidth={2.2} />}
        onClick={() => setIsConfirming(true)}
      >
        Clear picks
      </Button>
    );
  }

  return (
    <HStack
      gap={2}
      pl={3}
      pr={1.5}
      py={1.5}
      borderRadius="chip"
      bg="heart.50"
      borderWidth="1px"
      borderColor="heart.200"
      role="group"
      aria-label="Confirm clearing this week's picks"
    >
      <Text fontSize="meta" fontWeight={600} color="heart.700" whiteSpace="nowrap">
        Clear all {count}?
      </Text>
      <Button
        size="sm"
        h="32px"
        variant="quiet"
        borderColor="heart.200"
        color="heart.700"
        _hover={{ bg: 'heart.100' }}
        onClick={() => setIsConfirming(false)}
      >
        Keep
      </Button>
      <Button
        size="sm"
        h="32px"
        px={3.5}
        bg="heart.500"
        color="paper.base"
        _hover={{ bg: 'heart.600' }}
        _active={{ bg: 'heart.700' }}
        isLoading={isClearing}
        onClick={() => {
          setIsConfirming(false);
          onClear();
        }}
      >
        Clear all
      </Button>
    </HStack>
  );
}
