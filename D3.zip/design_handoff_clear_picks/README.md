# Handoff: Clear picks — reset the week's dinner selection

## Overview

The catalog page (`/`, `CatalogPage.tsx`) lets you pick up to three dinners for the week. Today the only
way to undo those picks is to un-pick each card one at a time, or to go to `/plan` and press the small ×
on each row three times. There is no way to start the week's picks over.

This handoff adds one control: **Clear picks**, in the catalog header, directly beside the "N of 3" count
badge it undoes. It asks once before clearing, then offers Undo.

The design is option **1a** from the design file. Option 1b (a "picked this week" chip strip above the
list, with "Start over") was reviewed and **not** chosen — it is still visible in the design file for
context, but do not build it.

## About the design files

`Reset Dinner Selection.dc.html` in this bundle is a **design reference created in HTML** — a working
prototype of the intended look and behavior, not production code to copy. Open it in a browser: both
options are interactive (pick, clear, confirm, undo).

The target codebase for this work is the existing **Dinner Ideas** app: React 19 + TypeScript + Vite,
Chakra UI v2 with a custom theme, TanStack Query, Supabase, React Router, Vitest + Testing Library. Build
this feature with those patterns — the prototype's inline styles exist only because the prototype is a
standalone HTML file. Every color, radius, and type value in it comes from `src/shared/theme/index.ts`
and should be referenced through Chakra tokens, never hardcoded.

The two `.reference.tsx` / `.reference.ts` files in this bundle are written against the real repo and are
much closer to shippable — but they have not been run or tested. Treat them as a strong starting point,
not as verified code.

## Fidelity

**High-fidelity.** Colors, typography, spacing, radii, and states are final and are all existing theme
tokens. Recreate the control exactly. The one judgement call left open is noted under
"Open question" at the bottom.

## Screens / views

### Catalog page header (`src/features/dinners/components/CatalogPage.tsx`)

**Purpose:** browse dinners, see how many are picked for the week, and — new — clear all picks at once.

**Layout, unchanged:** the header is an `HStack` with `justify="space-between"`, `mb={4}`,
`flexWrap="wrap"`, `gap={3}`. Left: an eyebrow (`textStyle="eyebrow"`, "This week") above an `h1`
(`textStyle="pageTitle"`, "Dinner catalog"). Right: an `HStack gap={2}` holding the count `Badge` and the
"Not interested" `IconButton`.

**Change:** the new control is inserted into that right-hand `HStack`, **between the count badge and the
"Not interested" icon button**. Nothing else in the header moves. On narrow phones the right-hand stack
already wraps below the title via `flexWrap="wrap"`; that behavior carries over unchanged, and the header's
minimum height stays 44px.

#### State: idle, 1–3 picked

A single quiet button.

| Property | Value |
| --- | --- |
| Component | Chakra `Button` `variant="quiet"` `size="sm"` (both exist in the theme) |
| Height | 34px (`size="sm"`), min-width 34px |
| Padding | `px={3}` (12px) |
| Radius | `chip` (999px) |
| Background | transparent |
| Border | 1px `line.DEFAULT` `#E0DCD1` |
| Text | "Clear picks", Outfit 600, 12px (`size="sm"` → `0.75rem`), color `ink.400` `#726C5B` |
| Icon | `uiIcons.restore` (lucide `RotateCcw`), 13px, `strokeWidth={2.2}`, `leftIcon`, gap 6px, `currentColor` |
| Hover | bg `paper.subtle` `#FAF8F3`, text `ink.700` `#5C5749` (the `quiet` variant's built-in `_hover`) |
| Focus | global olive ring — `0 0 0 3px rgba(74, 103, 65, 0.28)`, already in `styles.global` |

#### State: idle, 0 picked

**Renders nothing.** No disabled button, no placeholder. The control appears the moment the first dinner
is picked. Same rule when the current plan is `null` or `locked_at !== null` — in both of those cases
`selectedDinnerIds` is already an empty set in `CatalogPage`, so the existing derived value covers it and
no extra guard is needed.

#### State: confirm

Clicking "Clear picks" replaces the button in place with an inline confirm pill. This is deliberately not
a modal: the action is one row's worth of consequence and is undoable, so a dialog would be too heavy —
but it is destructive enough that a single mis-tap should not wipe the week.

| Property | Value |
| --- | --- |
| Container | `HStack gap={2}`, `pl={3}` `pr={1.5}` `py={1.5}`, radius `chip`, bg `heart.50` `#FBF1EC`, 1px border `heart.200` `#F0DDD4` |
| Label | "Clear all 3?" (the number is the live count), Outfit 600, `fontSize="meta"` 12.5px, color `heart.700` `#8E4633`, `whiteSpace="nowrap"` |
| "Keep" | `Button size="sm"` `h="32px"`, transparent, 1px `heart.200`, text `heart.700`, hover bg `heart.100` `#F7E6DE` |
| "Clear all" | `Button size="sm"` `h="32px"` `px={3.5}`, bg `heart.500` `#B3543F`, text `paper.base` `#FFFDFA`, hover `heart.600` `#9E4A37`, active `heart.700` `#8E4633` |

"Clear all" is the **only** filled terracotta button in the app — the theme comment on `heart` says it is
"never a button fill". Keep that rule intact: style this one instance with props on the call site, do not
add a `danger` Button variant to the theme. A second destructive fill anywhere else should reopen that
decision properly.

Confirm dismisses back to idle when: "Keep" is pressed, `Escape` is pressed, or the user picks/un-picks
any dinner card while the confirm is open.

#### State: cleared (undo)

After a successful clear, the confirm pill disappears (count is now 0, so the control renders nothing) and
an undo bar appears **below the header, above the filters** — in the same slot the existing
`toggleSelection.isError` alert occupies.

| Property | Value |
| --- | --- |
| Container | `HStack justify="space-between" gap={2.5}`, bg `paper.subtle` `#FAF8F3`, 1px `line.subtle` `#EDE9DE`, radius `field` (14px), `pl={3}` `pr={2.5}` `py={2.5}`, `mb={4}` |
| Icon | lucide `Info` (`uiIcons.info`), 15px, `strokeWidth={1.8}`, color `ink.400` `#726C5B` |
| Text | "3 dinners cleared." — singularize at 1 ("1 dinner cleared."). Outfit 400, 12.5px, `ink.700` `#5C5749`, line-height 1.4 |
| "Undo" | `Button variant="outline" size="sm"` `h="32px"`, 1px `line.brand` `#CFD6C2`, text `brand.500` `#4A6741`, hover bg `brand.50` `#F3F5EE`, `leftIcon` = `uiIcons.restore` 13px stroke 2.2 |

The bar persists until one of: Undo is pressed, the user picks another dinner, or they navigate away. It
does **not** auto-dismiss on a timer — the primary user reads at her own pace, and a disappearing undo is a
worse failure than a bar that lingers.

## Interactions & behavior

Flow: `idle → (tap Clear picks) → confirm → (tap Clear all) → mutation → cleared+undo bar → (tap Undo) → idle with picks restored`.

- **Clearing** removes every selection on the live plan in one request (see
  `clear-selections.reference.ts` §1). It does **not** delete the plan row — an empty draft plan is a
  valid state the catalog already renders as "0 of 3".
- **In flight:** "Clear all" shows its `isLoading` spinner. Dinner-card pick buttons should be disabled
  while it runs, reusing the same reasoning as the existing `selectionDisabled` guard in `CatalogPage`.
- **Undo** re-adds the removed dinner ids **sequentially, in their original order**, so the 1/2/3 badges
  on `/plan` come back as they were. Order is insert order; `Promise.all` would scramble it.
- **Errors:** on failure of either mutation, show the page's existing error `Alert` pattern —
  "Couldn't clear your picks, try again." / "Couldn't undo that, try again." — in the same slot as the
  existing `toggleSelection.isError` alert. The optimistic UI should not clear the cards until the
  mutation resolves.
- **Locked plan:** hidden. Once a plan is locked (`locked_at !== null`) its shopping list has been sent
  and its picks are history.
- **Keyboard:** `Clear picks` → `Enter/Space` opens confirm and moves focus to "Keep" (the safe option).
  `Escape` cancels. After a successful clear, focus moves to the "Undo" button. Give the confirm pill
  `role="group"` and `aria-label="Confirm clearing this week's picks"`.
- **Screen reader:** announce the cleared bar with `aria-live="polite"`.
- **Responsive:** no breakpoint-specific behavior. The control is the same at every width; it simply
  wraps with the header stack it lives in. All three buttons are ≥32px tall inside a 44px-tall header
  row, matching the existing `size="sm"` header controls.

## State management

Component-local, in `ClearPicksControl`:

- `isConfirming: boolean` — idle vs. confirm.

Page-level, in `CatalogPage`:

- `clearedIds: string[] | null` — the ids removed by the last clear; drives the undo bar. `null` hides it.
- Existing `currentPlan` query supplies the plan id and the live selections; existing `selectedDinnerIds`
  memo supplies the count.

Data layer (see `clear-selections.reference.ts`):

- `clearSelections(planId)` in `weekly-plan/api.ts` — one `delete().eq('weekly_plan_id', planId)`.
- `useClearSelections()` — returns the removed dinner ids, invalidates `['weekly-plan','current']`.
- `useRestoreSelections()` — sequential `addSelection` calls, same invalidation.

Do **not** implement clear as three `useToggleSelection` calls. That hook derives its add/remove decision
from a `currentPlan` snapshot handed in by the caller, so firing it repeatedly from one snapshot is the
exact stale-snapshot hazard the existing `selectionDisabled` comment in `CatalogPage` guards against.

## Design tokens

All already defined in `src/shared/theme/index.ts` — reference them, don't hardcode.

**Color**
`brand.50 #F3F5EE` · `brand.100 #EEF1E8` · `brand.500 #4A6741` · `brand.600 #3E5636`
`heart.50 #FBF1EC` · `heart.100 #F7E6DE` · `heart.200 #F0DDD4` · `heart.500 #B3543F` · `heart.600 #9E4A37` · `heart.700 #8E4633`
`paper.base #FFFDFA` · `paper.subtle #FAF8F3` · `paper.sunken #F1EEE6`
`line.subtle #EDE9DE` · `line.DEFAULT #E0DCD1` · `line.brand #CFD6C2` · `line.brandSubtle #E3E7DA`
`ink.900 #232019` · `ink.700 #5C5749` · `ink.500 #7E7869` · `ink.400 #726C5B` · `ink.300 #757060`

**Radius** `chip 999px` · `control 12px` · `field 14px` · `card 16px`

**Type** Lora 400–600 (headings) · Outfit 300–700 (UI). Sizes used here: `meta 12.5px`, `sm` button
`12px`, `eyebrow 11px`. Nothing below 11px.

**Spacing** Chakra scale. Used: `1.5` (6px), `2` (8px), `2.5` (10px), `3` (12px), `3.5` (14px), `4` (16px).

**Motion** None. No transition on the state swap — the confirm pill replaces the button instantly. The
theme has almost no shadow and no motion vocabulary; adding one for this control would be out of place.

## Assets

No new assets. Both icons already exist in `src/shared/components/icons.tsx`:
`uiIcons.restore` (lucide `RotateCcw`) and `uiIcons.info` (lucide `Info`). No new lucide imports needed.

## Files to touch

| File | Change |
| --- | --- |
| `src/features/weekly-plan/components/ClearPicksControl.tsx` | **new** — see `ClearPicksControl.reference.tsx` |
| `src/features/weekly-plan/components/ClearPicksControl.test.tsx` | **new** — idle/confirm/hidden-at-zero, Escape cancels, onClear fires once |
| `src/features/weekly-plan/api.ts` | add `clearSelections` |
| `src/features/weekly-plan/hooks.ts` | add `useClearSelections`, `useRestoreSelections` |
| `src/features/dinners/components/CatalogPage.tsx` | mount the control in the header stack; own `clearedIds` and the undo bar |
| `src/features/dinners/components/CatalogPage.test.tsx` | extend — clear empties the grid, undo restores it, control absent at 0 picks and when locked |

Nothing in `PlanPage.tsx` changes. The per-selection × there stays as it is; if you later want the same
reset on `/plan`, the control is already prop-driven and drops in beside the week nav — but that was not
part of this request.

## Bundle contents

- `README.md` — this file
- `Reset Dinner Selection.dc.html` — interactive design reference (option **1a** is the build target; 1b is context only)
- `ClearPicksControl.reference.tsx` — reference component, untested
- `clear-selections.reference.ts` — reference api/hooks additions, untested

## Open question for the product owner

**Should Undo survive a page navigation?** As specified, it does not — leaving the catalog drops the
undo bar, and the clear becomes permanent. That is the simple build. Persisting it (session storage, or a
soft-delete column) is a materially larger change and was not scoped here.
